import React from 'react';

const About = () => {
  return (
    <div>
      <h1>About Page</h1>

      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. A aliquam architecto velit! Aperiam eius non odio optio</p>
    </div>
  );
};

export default About;